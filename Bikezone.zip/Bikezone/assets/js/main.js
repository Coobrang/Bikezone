// Video Popup

function openModal() {
    document.getElementById("myModal").style.display = "flex";
    document.getElementById("modalVideo").src = "https://www.youtube.com/embed/s3aKWkPwig0?autoplay=1";
}

function closeModal() {
    document.getElementById("myModal").style.display = "none";
    var video = document.getElementById("modalVideo");
    video.src = "";
}

window.onclick = function(event) {
    var modal = document.getElementById("myModal");
    if (event.target == modal) {
        closeModal();
    }
}

// MObile Menu
const menuBtn = document.querySelector('.menu-btn');
const mobileMenu = document.querySelector('.mobilemenu');

menuBtn.addEventListener('click', () => {
  menuBtn.classList.toggle('active');
  mobileMenu.classList.toggle('active');
  menuBtn.querySelector('i').classList.toggle('fa-bars');
  menuBtn.querySelector('i').classList.toggle('fa-times');
});
